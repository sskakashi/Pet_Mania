from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from .models import PetPost, Category
from .forms import PetPostForm
from django.contrib.auth import authenticate, login, logout
from django.db.models import Q

def home(request):
    category_id = request.GET.get('category')
    if category_id and category_id != 'all':
        posts = PetPost.objects.filter(category_id=category_id)
    else:
        posts = PetPost.objects.all()
    
    posts = posts.order_by('-created_at')
    categories = Category.objects.all()
    return render(request, 'home.html', {'posts': posts, 'categories': categories})

def post_detail(request, post_id):
    post = get_object_or_404(PetPost, id=post_id)
    categories = Category.objects.all()
    return render(request, 'post_detail.html', {'post': post, 'categories': categories})

def category_posts(request, category_id):
    category = get_object_or_404(Category, id=category_id)
    posts = PetPost.objects.filter(category=category).order_by('-created_at')
    categories = Category.objects.all()
    return render(request, 'home.html', {'posts': posts, 'categories': categories, 'current_category': category})

def search(request):
    query = request.GET.get('q')
    posts = PetPost.objects.filter(Q(name__icontains=query) | Q(caption__icontains=query)).order_by('-created_at') if query else PetPost.objects.all()
    categories = Category.objects.all()
    return render(request, 'home.html', {'posts': posts, 'categories': categories, 'query': query})

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('adoption:home')
    categories = Category.objects.all()
    return render(request, 'login.html', {'categories': categories})

def logout_view(request):
    logout(request)
    return redirect('adoption:home')

@login_required
def add_pet(request):
    if request.method == 'POST':
        form = PetPostForm(request.POST, request.FILES)
        if form.is_valid():
            pet = form.save(commit=False)
            pet.user = request.user  # Auto-set current user
            pet.save()
            return redirect('home')

@login_required
def add_pet(request):
    if request.method == 'POST':
        form = PetPostForm(request.POST, request.FILES)
        if form.is_valid():
            pet = form.save(commit=False)
            pet.user = request.user
            pet.save()
            return redirect('adoption:home')
    else:
        form = PetPostForm()
    return render(request, 'add_pet.html', {'form': form, 'categories': Category.objects.all()})

@login_required
def delete_pet(request, pet_id):
    pet = get_object_or_404(PetPost, id=pet_id, user=request.user)
    if request.method == 'POST':
        pet.delete()
        return redirect('adoption:home')
    return render(request, 'confirm_delete.html', {'pet': pet, 'categories': Category.objects.all()})

@login_required
def add_pet(request):
    if request.method == 'POST':
        form = PetPostForm(request.POST, request.FILES)
        if form.is_valid():
            pet = form.save(commit=False)
            pet.user = request.user
            pet.save()
            return redirect('adoption:home')
    else:
        form = PetPostForm()
    return render(request, 'add_pet.html', {'form': form}) 