from django.db import models
from django.contrib.auth.models import User


from django.conf import settings
from django.contrib.auth import get_user_model

class PetPost(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    # ... your other fields ...

    
class Category(models.Model):
    name = models.CharField(max_length=100, unique=True)  # Ensure no duplicate categories

    def __str__(self):
        return self.name

class PetPost(models.Model):
    name = models.CharField(max_length=200, verbose_name="Pet Name")  # More user-friendly label
    caption = models.TextField(verbose_name="About the Pet")          # Better form display
    image = models.ImageField(upload_to='pets/', blank=True, null=True)
    category = models.ForeignKey(Category, on_delete=models.CASCADE, verbose_name="Pet Type")
    user = models.ForeignKey(User, on_delete=models.CASCADE, editable=False)  # Auto-set to current user
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} ({self.category})"