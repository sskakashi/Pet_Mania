from django.contrib import admin
from .models import PetPost, Category

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name',)
    search_fields = ('name',)
    list_filter = ('name',)

from django.contrib import admin
from .models import PetPost

@admin.register(PetPost)
class PetPostAdmin(admin.ModelAdmin):
    exclude = ('user',)  # Hide user field from admin
    
    def save_model(self, request, obj, form, change):
        if not obj.user_id:  # Auto-set current user
            obj.user = request.user
        super().save_model(request, obj, form, change)