from django import forms
from .models import PetPost, Category

class PetPostForm(forms.ModelForm):
    class Meta:
        model = PetPost
        fields = ['name', 'caption', 'image', 'category']  # 'user' is auto-set; no need in form
        labels = {
            'name': 'Pet Name',
            'caption': 'Tell us about the pet',
        }

    # Dynamically load categories in the dropdown
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['category'].queryset = Category.objects.all()

        from django import forms
from .models import PetPost

class PetPostForm(forms.ModelForm):
    class Meta:
        model = PetPost
        exclude = ('user',)  # Hide user field from forms