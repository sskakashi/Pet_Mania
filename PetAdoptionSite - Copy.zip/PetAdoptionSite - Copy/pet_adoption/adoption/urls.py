from django.urls import path
from . import views

app_name = 'adoption'

urlpatterns = [
    path('', views.home, name='home'),  # Changed back to 'home' to match views.py
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('add/', views.add_pet, name='add_pet'),
    path('post/<int:post_id>/', views.post_detail, name='post_detail'),
    path('category/<int:category_id>/', views.category_posts, name='category_posts'),
    path('search/', views.search, name='search'),
    path('delete/<int:pet_id>/', views.delete_pet, name='delete_pet'),
]